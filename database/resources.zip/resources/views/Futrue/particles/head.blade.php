<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta charset="utf-8">
  <!-- Title and other stuffs -->
  <title>未来笔记</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">



 <!-- Stylesheets -->
  <link href="{{asset('futrue/style/bootstrap.css')}}" rel="stylesheet">
  <!-- Font awesome icon -->
 <link href="{{asset('futrue/style/font-awesome.min.css')}}" rel="stylesheet" rel="stylesheet">  <!-- Flexslider -->
  <!-- prettyPhoto -->
  <!-- Bootstrap responsive -->
  <link href="{{asset('futrue/style/bootstrap-responsive.css')}}" rel="stylesheet">
  <!-- HTML5 Support for IE -->
 <script src="{{asset('futrue/js/clock.js')}}"></script>

  <!--[if lt IE 9]>

  <![endif]-->
<!-- Main stylesheet -->
  <link href="{{asset('futrue/style/style.css')}}" rel="stylesheet">

  <link href="{{asset('futrue/style/style2.css')}}" rel="stylesheet">
  <!-- Favicon -->
  <link rel="shortcut icon" href="{{asset('futrue/img/favicon/favicon.png')}}">
</head>
